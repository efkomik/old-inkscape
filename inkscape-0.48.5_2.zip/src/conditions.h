#ifndef CONDITIONS_H_
#define CONDITIONS_H_

#include "sp-item.h"

bool sp_item_evaluate(SPItem const *item);

#endif /*CONDITIONS_H_*/
